Real datasets moved to Google Drive:
https://drive.google.com/drive/folders/1saUUJl9waEzRSWW8MJjS9y0vbbl6VeBx


This folder should have the following structure:
```
├── info.txt
└── real
    ├── DowJones
    │   └── DowJones_diff_2.csv
    ├── SP500
    │   └── SP500.csv
    └── wind
        ├── pres.csv
        ├── pres_diff.csv
        ├── url_used.txt
        ├── url_wind.txt
        ├── wind1.csv
        ├── wind1_diff.csv
        ├── wind_dir.csv
        ├── wind_dir_diff.csv
        └── wind-measurements_papua-new-guinea_launakalana_wb-esmap_qc.csv
```